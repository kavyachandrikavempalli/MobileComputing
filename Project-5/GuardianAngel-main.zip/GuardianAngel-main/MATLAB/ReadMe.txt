Steps to Run the project:

1. Please open thinkSpeak API in browser. 
2. Check for the values and last updated time.
3. Update from mobile app, need to change NumMinutes accordingly
4. Input the values (Alternatively you can load user_data to test the code if the API is not working)
5. Run Matlab Code.
6. The output will be uploaded to the Channel.