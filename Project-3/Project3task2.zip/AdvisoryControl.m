%% Load data from Excel file
User_data=[1,80,14,16,6,95,26,21,14;2,65,15,13,4,71,21,14,5;3,61,14,17,8,92,23,26,16];
User_3=User_data(3,:);
%timesample
%matlabfunction

%% Extract HR and RR data for LCW and HCW
lcw_hr = User_data(3, [2, 3]);
lcw_rr = User_data(3, [4, 5]);
hcw_hr = User_data(3, [6, 7]);
hcw_rr = User_data(3, [8, 9]);

%% Generate random samples for user 3
lcw_hr_val = normrnd(lcw_hr(1, 1), lcw_hr(1, 2),50,1);
lcw_rr_val = normrnd(lcw_rr(1, 1), lcw_rr(1, 2),50,1);
hcw_hr_val = normrnd(hcw_hr(1, 1), hcw_hr(1, 2),50,1);
hcw_rr_val = normrnd(hcw_rr(1, 1), hcw_rr(1, 2),50,1);

%% Calculate the mean value
Hr_lcw = mean(lcw_hr_val);
Rr_lcw = mean(lcw_rr_val);

Hr_hcw = mean(hcw_hr_val);
Rr_hcw = mean(hcw_rr_val);
load("workspace.mat");

%%
VA=40;
decelB=-150;
decelLim=-300;
initSpeedA=45;
initSpeedB=40;
load_system("LaneMaintainSystem3Car.slx");
set_param('LaneMaintainSystem3Car/VehicleKinematics/Saturation','LowerLimit',num2str(decelLim));
set_param('LaneMaintainSystem3Car/VehicleKinematics/vx','InitialCondition',num2str(initSpeedB));
set_param('LaneMaintainSystem3Car/CARA/VehicleKinematics/Saturation','LowerLimit',num2str(decelLim));
set_param('LaneMaintainSystem3Car/CARA/VehicleKinematics/vx','InitialCondition',num2str(initSpeedA));
sim("LaneMaintainSystem3Car.slx");

% set_param('Level3Model/VehicleKinematics/Saturation','LowerLimit',num2str(100*decelLim))
% set_param('Level3Model/VehicleKinematics/vx','InitialCondition',num2str(initSpeedB))
% set_param('Level3Model/CARA/VehicleKinematics/Saturation','LowerLimit',num2str(decelLim))
% set_param('Level3Model/CARA/VehicleKinematics/vx','InitialCondition',num2str(initSpeedA))
% set_param('Level3Model/Constant1','Value',num2str(timeToSwitchToHuman))
% set_param('Level3Model/Step','Time',num2str(HumanReactionTime+timeToSwitchToHuman))
% set_param('Level3Model/Step','After',num2str(1.1*decelLim))
time=0;
stoptime=get_param(gcs,'StopTime');
for Case=1:2
    while time<stoptime
if decelB>(0.75*decelLim)
    disp("Switch to Human");
    decelhuman=1.1*decelLim;
    %time of switch
    timeToSwitchToHuman=0.3;
    if Case==1
        HumanReactionTime=(Hr_lcw/Rr_lcw)*0.01;
    else
        HumanReactionTime=(Hr_hcw/Rr_hcw)*0.01;
    end
    load_system("Level3Model.slx");
    set_param('Level3Model/VehicleKinematics/Saturation','LowerLimit',num2str(100*decelLim));
    set_param('Level3Model/VehicleKinematics/vx','InitialCondition',num2str(initSpeedB));
    set_param('Level3Model/CARA/VehicleKinematics/Saturation','LowerLimit',num2str(decelLim));
    set_param('Level3Model/CARA/VehicleKinematics/vx','InitialCondition',num2str(initSpeedA));
    set_param('Level3Model/Constant1','Value',num2str(timeToSwitchToHuman));
    set_param('Level3Model/Step','Time',num2str(HumanReactionTime+timeToSwitchToHuman));
    set_param('Level3Model/Step','After',num2str(1.1*decelLim));
    sim("Level3Model.slx");
else
    disp("Autonomous");
end
    time=time+1;
    end
end
