package com.example.maps

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.android.gms.common.api.Status
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import java.io.IOException
import android.location.Address
import android.location.Geocoder
import android.view.View
import com.example.maps.R.string.google_maps_api_key
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.DirectionsApi
import com.google.maps.GeoApiContext
import com.google.maps.model.TravelMode

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private var mGoogleMap:GoogleMap? = null
    private lateinit var autocompleteStartFragment: AutocompleteSupportFragment
    private lateinit var autocompleteEndFragment: AutocompleteSupportFragment
    private lateinit var startCord: LatLng
    private lateinit var endCord: LatLng
    private val zoom = 12f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiKey = getString(google_maps_api_key)
        val context = GeoApiContext.Builder().apiKey(apiKey).build()

        Places.initialize(applicationContext, apiKey)
//        if (findViewById<View>(R.id.autocomplete_fragment_start).visibility == View.VISIBLE){
//            autocompleteFragment = supportFragmentManager.findFragmentById(R.id.autocomplete_fragment_start) as AutocompleteSupportFragment
//        }else{
//            autocompleteFragment = supportFragmentManager.findFragmentById(R.id.autocomplete_fragment_end) as AutocompleteSupportFragment
//        }
//        autocompleteFragment.setPlaceFields(listOf(Place.Field.ID, Place.Field.ADDRESS, Place.Field.LAT_LNG))
//        autocompleteFragment.setOnPlaceSelectedListener(object :PlaceSelectionListener {
//            override fun onError(p0: Status) {
//                Toast.makeText(this@MainActivity,"Error in Search", Toast.LENGTH_SHORT).show()
//            }
//
//            override fun onPlaceSelected(p0: Place) {
//                val address = p0.address
//                //val id = p0.id
//                //val latLng = p0.latLng
//                val latLng = geocodeAddress(address)
//                val zoom = 12f
//                if (latLng != null) {
//                    zoomOnMap(latLng,zoom)
//                    if (findViewById<View>(R.id.autocomplete_fragment_start).visibility == View.VISIBLE){
//                        R.id.autocomplete_fragment_start = View.GONE
//                        R.id.autocomplete_fragment_end = View.VISIBLE
//                        addMarker(latLng,"Start")
//                    }else{
//                        R.id.autocomplete_fragment_start = View.VISIBLE
//                        R.id.autocomplete_fragment_end = View.GONE
//                        addMarker(latLng,"End")
//                    }
//                }
//            }
//
//        })

        autocompleteStartFragment = supportFragmentManager.findFragmentById(R.id.autocomplete_fragment_start) as AutocompleteSupportFragment
        autocompleteEndFragment = supportFragmentManager.findFragmentById(R.id.autocomplete_fragment_end) as AutocompleteSupportFragment
        autocompleteStartFragment.setPlaceFields(listOf(Place.Field.ID,Place.Field.ADDRESS,Place.Field.LAT_LNG))
        autocompleteEndFragment.setPlaceFields(listOf(Place.Field.ID,Place.Field.ADDRESS,Place.Field.LAT_LNG))
        autocompleteStartFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onError(p0: Status) {Toast.makeText(this@MainActivity, "Error in Search", Toast.LENGTH_SHORT).show()}
            override fun onPlaceSelected(p0: Place) {
                val address = p0.address
                //val id = p0.id
                //val latLng = p0.latLng
                startCord = address?.let { addressToCord(it) }!!
                zoomOnMap(startCord, zoom)
                addMarker(startCord, "Start")
                findViewById<View>(R.id.autocomplete_fragment_end).visibility = View.VISIBLE
                findViewById<View>(R.id.autocomplete_fragment_start).visibility = View.GONE
            }
        })

        autocompleteEndFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onError(p0: Status) {Toast.makeText(this@MainActivity, "Error in Search", Toast.LENGTH_SHORT).show()}
            override fun onPlaceSelected(p1: Place) {
                val address = p1.address
                //val id = p0.id
                //val latLng = p0.latLng
                endCord = address?.let { addressToCord(it) }!!
                zoomOnMap(endCord, zoom)
                addMarker(endCord, "End")
                findViewById<View>(R.id.startCV).visibility = View.GONE
                getTrafficData(context)
            }
        })

//        if (findViewById<View>(R.id.startCV).visibility == View.GONE){
//            val directionsResult = DirectionsApi.getDirections(context, startCord.toString(), endCord.toString())
//                .mode(TravelMode.DRIVING)
//                .await()
//            if (directionsResult != null) {
//                // You can access the traffic data in result.routes
//                val route = directionsResult.routes[0]
//                val trafficData = route.legs[0].durationInTraffic
//                Toast.makeText(this,""+trafficData,Toast.LENGTH_LONG).show()
//            } else {
//                Toast.makeText(this,"Failed to retrieve directions",Toast.LENGTH_SHORT).show()
//            }
//        }

//        val request = DirectionsApiRequest.newBuilder()
//            .origin("Source Address or Coordinates")
//            .destination("Destination Address or Coordinates")
//            .trafficModel(TrafficModel.BEST_GUESS) // You can choose different traffic models
//            .build()
//
//        val result = directionsApi.request(request)




        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun addressToCord(address: String): LatLng? {
        val geocoder = Geocoder(this)
        try {
            val results: MutableList<Address>? = geocoder.getFromLocationName(address, 1)
            if (results != null) {
                val location = results[0]
                return LatLng(location.latitude, location.longitude)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }


    private fun zoomOnMap(latLng:LatLng,zoom:Float){
        val newLatLngZoom = CameraUpdateFactory.newLatLngZoom(latLng,zoom)
        mGoogleMap?.animateCamera(newLatLngZoom)
    }

    private fun addMarker(latLng: LatLng,flag:String){
        mGoogleMap?.addMarker((MarkerOptions().position(latLng).title(flag)))
    }

    private fun getTrafficData(context: GeoApiContext){
        Toast.makeText(this,"Hmm",Toast.LENGTH_SHORT).show()
//        val directionsResult = DirectionsApi.getDirections(context, startCord.toString(), endCord.toString()).mode(TravelMode.DRIVING).await()
//        Toast.makeText(this,"Yes",Toast.LENGTH_SHORT).show()
//
//        try {
//            if(directionsResult != null) {
//                val route = directionsResult.routes[0]
//                val trafficData = route.legs[0].durationInTraffic
//                Toast.makeText(this, "" + trafficData, Toast.LENGTH_LONG).show()
//            }
//        }catch (e: IOException) {
//            e.printStackTrace()
//        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mGoogleMap = googleMap
    }
}